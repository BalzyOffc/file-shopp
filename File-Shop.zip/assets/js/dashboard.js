(async()=>{
const u=await requireAuth();if(!u)return;
const{profile}=await getUserProfile();
const{data:wallet}=await sb.from("wallets").select("balance").eq("user_id",u.id).maybeSingle();
document.querySelector("#app").innerHTML=nav()+`<main class="page"><section class="hero"><span class="eyebrow">TOKO</span><h1>Produk</h1><p class="muted">Pilih produk berdasarkan kategori.</p><div class="wallet-mini card">💰 Saldo: <b>Rp ${money(wallet?.balance||0)}</b> · <a href="wallet.html">Isi saldo</a></div></section><section class="toolbar card"><input id="search" placeholder="Cari produk..."><select id="cat"><option value="">Semua kategori</option></select></section><section id="products" class="product-grid"></section></main>`;
wireNav(profile);

const search=document.getElementById("search");
const cat=document.getElementById("cat");
const productList=document.getElementById("products");

const[
 {data:cats,error:catError},
 {data:productRows,error:productError}
]=await Promise.all([
 sb.from("categories").select("id,name").eq("is_active",true).order("name"),
 sb.from("products").select("*,categories(name)").eq("is_active",true).order("created_at",{ascending:false})
]);

if(catError||productError){
 productList.innerHTML=`<div class="card"><b>Gagal memuat produk.</b><p class="muted">${esc(catError?.message||productError?.message||"Terjadi kesalahan.")}</p></div>`;
 return;
}

(cats||[]).forEach(c=>cat.insertAdjacentHTML("beforeend",`<option value="${esc(c.id)}">${esc(c.name)}</option>`));
const all=productRows||[];

function render(){
 const q=(search.value||"").toLowerCase().trim();
 const c=cat.value;
 const filtered=all.filter(p=>
   (!q||String(p.name||"").toLowerCase().includes(q))&&
   (!c||p.category_id===c)
 );
 productList.innerHTML=filtered.length
 ?filtered.map(p=>`<article class="product-card"><img src="${esc(p.image_url||"https://placehold.co/600x400/130b1d/fff?text=Product")}"><div class="product-body"><span class="tag">${esc(p.categories?.name||"Umum")}</span><h3>${esc(p.name)}</h3><p class="muted">${esc(p.description||"")}</p><div class="product-bottom"><b>Rp ${money(p.price)}</b><span>Stok ${p.stock}</span></div><button class="btn primary buy" data-id="${p.id}" ${p.stock<=0?"disabled":""}>${p.stock>0?"Pesan":"Habis"}</button></div></article>`).join("")
 :"<div class='card'>Produk tidak ditemukan.</div>";

 productList.querySelectorAll(".buy").forEach(b=>{
   b.onclick=()=>location.href="checkout.html?product="+encodeURIComponent(b.dataset.id);
 });
}
search.oninput=render;
cat.onchange=render;
render();
})();
function money(v){return Number(v||0).toLocaleString("id-ID")}
