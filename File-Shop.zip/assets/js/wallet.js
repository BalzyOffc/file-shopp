/* ============================================================
   wallet.js — versi perbaikan
   Perbaikan utama:
   1. Fungsi fetch saldo dipisah jadi `loadWallet(force)` → bisa
      dipanggil ulang untuk refresh tanpa reload.
   2. Auto-refresh saat tab kembali aktif / window focus.
   3. Polling ringan tiap 15 detik (hanya saat tab visible).
   4. Realtime Supabase: saldo update otomatis begitu admin
      approve di tabel wallets / wallet_deposits.
   5. Fix bug: `deposit.onsubmit` → gunakan document.getElementById,
      karena `deposit` bukan variabel global (bergantung pada
      browser auto-global dari id, tidak reliable).
   6. Fix bug: `w` (wallets) null → saldo tetap tampil 0, tapi
      kita tetap render UI walau deposit/settings error.
   7. Tombol disable + label loading saat submit deposit.
   ============================================================ */

let __walletChannel = null;
let __walletPollTimer = null;
let __currentUser = null;

async function loadWallet(force = false) {
  const app = document.querySelector("#app");
  if (!app) return;

  const u = __currentUser || (await requireAuth());
  if (!u) return;
  __currentUser = u;

  const { profile } = await getUserProfile();

  const [wRes, dRes, sRes] = await Promise.all([
    sb.from("wallets").select("balance").eq("user_id", u.id).maybeSingle(),
    sb.from("wallet_deposits").select("*").eq("user_id", u.id)
      .order("created_at", { ascending: false }).limit(20),
    sb.from("site_settings").select("qris_image_url").eq("id", 1).maybeSingle(),
  ]);

  const balance = Number(wRes?.data?.balance || 0);
  const deposits = dRes?.data || [];
  const qrisUrl = sRes?.data?.qris_image_url || "";

  const label = { pending: "Menunggu", approved: "Disetujui", rejected: "Ditolak" };

  app.innerHTML = nav() + `
    <main class="page">
      <section class="hero">
        <span class="eyebrow">WALLET</span>
        <h1>Saldo Saya</h1>
        <p class="muted">Deposit manual melalui QRIS admin.</p>
      </section>

      <section class="wallet-balance card">
        <span class="muted">Saldo tersedia</span>
        <strong id="wallet-balance-value">Rp ${money(balance)}</strong>
      </section>

      <section class="checkout-grid">
        <div class="card">
          <h2>Isi Saldo</h2>
          ${qrisUrl
            ? `<img class="qris" src="${esc(qrisUrl)}" alt="QRIS">`
            : `<p class="muted">QRIS belum diatur admin.</p>`}
          <p class="muted">
            Transfer nominal yang kamu masukkan ke QRIS di atas, lalu upload
            bukti pembayaran. Saldo hanya bertambah setelah admin menyetujui deposit.
          </p>
          <form id="deposit" class="form-grid">
            <input id="amount" type="number" min="1000" step="1000"
                   placeholder="Nominal deposit, contoh 25000" required>
            <input id="proof" type="file" accept="image/*,.pdf" required>
            <button class="btn primary" type="submit">Ajukan Deposit</button>
            <p id="msg" class="msg"></p>
          </form>
        </div>

        <div>
          <h2>Riwayat Deposit</h2>
          <section class="order-list">
            ${deposits.map(x => `
              <div class="card order">
                <div>
                  <b>Deposit Rp ${money(x.amount)}</b>
                  <p class="muted">${new Date(x.created_at).toLocaleString("id-ID")}</p>
                  ${x.status === "rejected" && x.reject_reason
                    ? `<p class="muted">Alasan: ${esc(x.reject_reason)}</p>` : ""}
                </div>
                <span class="status st-${esc(x.status)}">
                  ${esc(label[x.status] || x.status)}
                </span>
              </div>`).join("") || "<div class='card'>Belum ada deposit.</div>"}
          </section>
        </div>
      </section>
    </main>`;

  wireNav(profile);

/* ---------------- Form deposit ---------------- */
const form = document.getElementById("deposit");
const msg  = document.getElementById("msg");
const btn  = form ? form.querySelector("button") : null;

if (form) {
  // Pastikan button type="submit" (kalau bukan, set manual)
  if (btn && !btn.getAttribute("type")) btn.setAttribute("type", "submit");

  form.addEventListener("submit", async function (e) {
    // ⛔ WAJIB: cegah reload
    e.preventDefault();
    e.stopPropagation();

    if (!msg || !btn) return;

    const amountEl = document.getElementById("amount");
    const proofEl  = document.getElementById("proof");
    const amount   = Number(amountEl?.value || 0);
    const file     = proofEl?.files?.[0];

    // Validasi
    if (!Number.isFinite(amount) || amount < 1000) {
      msg.textContent = "Minimal deposit Rp1.000.";
      amountEl?.focus();
      return;
    }
    if (!file) {
      msg.textContent = "Upload bukti transfer dulu.";
      proofEl?.focus();
      return;
    }
    // Cek tipe file
    const okTypes = ["image/jpeg","image/png","image/webp","image/gif","application/pdf"];
    if (file.type && !okTypes.includes(file.type)) {
      msg.textContent = "Format harus JPG, PNG, WEBP, GIF, atau PDF.";
      return;
    }
    // Cek ukuran (maks 5MB)
    if (file.size > 5 * 1024 * 1024) {
      msg.textContent = "Ukuran file maksimal 5MB.";
      return;
    }

    // Disable tombol
    btn.disabled = true;
    const oldLabel = btn.textContent;
    btn.textContent = "Mengirim...";
    msg.textContent = "";

    try {
      const ext  = (file.name.split(".").pop() || "bin").toLowerCase();
      const uuid = (window.crypto && crypto.randomUUID)
        ? crypto.randomUUID()
        : String(Date.now()) + "-" + Math.random().toString(36).slice(2);
      const path = `${u.id}/wallet-${uuid}.${ext}`;

      // Upload ke storage
      const up = await sb.storage.from("payment-proofs").upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        contentType: file.type || undefined,
      });
      if (up.error) throw new Error("Upload gagal: " + up.error.message);

      const { data: pub } = sb.storage.from("payment-proofs").getPublicUrl(path);

      // Insert ke DB
      const { error: insErr } = await sb.from("wallet_deposits").insert({
        user_id: u.id,
        amount: amount,
        payment_proof_url: pub.publicUrl,
      });
      if (insErr) throw new Error("Simpan gagal: " + insErr.message);

      msg.textContent = "✅ Deposit terkirim. Menunggu persetujuan admin.";
      form.reset();

      // Refresh list deposit tanpa reload
      setTimeout(() => loadWallet(true), 800);

    } catch (err) {
      console.error("[wallet] deposit error:", err);
      msg.textContent = err.message || "Gagal mengirim deposit.";
    } finally {
      btn.disabled = false;
      btn.textContent = oldLabel;
    }
  });
}

/* ---------------- Auto-refresh & realtime ---------------- */
function startWalletWatchers() {
  // Refresh saat tab kembali aktif
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") loadWallet(true);
  });

  // Refresh saat window dapat fokus
  window.addEventListener("focus", () => loadWallet(true));

  // Polling ringan
  if (__walletPollTimer) clearInterval(__walletPollTimer);
  __walletPollTimer = setInterval(() => {
    if (document.visibilityState === "visible") loadWallet(true);
  }, 15000);

  // Realtime Supabase — saldo update begitu admin approve
  try {
    if (__walletChannel) sb.removeChannel(__walletChannel);
    __walletChannel = sb
      .channel("wallet-changes")
      .on("postgres_changes",
          { event: "*", schema: "public", table: "wallets" },
          () => loadWallet(true))
      .on("postgres_changes",
          { event: "*", schema: "public", table: "wallet_deposits" },
          () => loadWallet(true))
      .subscribe();
  } catch (e) {
    console.warn("[wallet] realtime tidak aktif:", e);
  }
}

function money(v) {
  return Number(v || 0).toLocaleString("id-ID");
}

/* ---------------- Bootstrap ---------------- */
(async () => {
  await loadWallet(true);
  startWalletWatchers();

  // expose untuk dipanggil dari luar (mis. wallet.html)
  window.loadWallet = loadWallet;
  window.fetchWallet = loadWallet;
})();