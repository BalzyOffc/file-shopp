(async()=>{
const u=await requireAuth();if(!u)return;
const{profile}=await getUserProfile();
const id=new URLSearchParams(location.search).get("product");
const{data:p}=await sb.from("products").select("*,categories(name)").eq("id",id).single();
if(!p){location.replace("dashboard.html");return}
const[{data:s},{data:w}]=await Promise.all([
 sb.from("site_settings").select("*").eq("id",1).single(),
 sb.from("wallets").select("balance").eq("user_id",u.id).maybeSingle()
]);
const walletBalance=Number(w?.balance||0);
document.querySelector("#app").innerHTML=nav()+`<main class="page"><section class="hero"><h1>Checkout</h1><p class="muted">Pilih metode pembayaran. Voucher bisa digunakan pada kedua metode.</p></section><section class="checkout-grid"><div class="card"><img class="checkout-img" src="${esc(p.image_url||"https://placehold.co/700x450")}"><h2>${esc(p.name)}</h2><p>${esc(p.description||"")}</p><b class="total" id="total">Rp ${money(p.price)}</b><div id="discountInfo" class="muted"></div></div><div class="card"><h2>Pembayaran</h2><label>Metode pembayaran</label><select id="method"><option value="qris">QRIS / Transfer</option><option value="wallet">Wallet / Saldo (Rp ${money(walletBalance)})</option></select><div id="qrisBox">${s?.qris_image_url?`<img class="qris" src="${esc(s.qris_image_url)}">`:`<p class='muted'>QRIS belum diatur admin.</p>`}<label>Username</label><input id="buyer" value="${esc(profile.username)}" autocapitalize="none" required><label>Bukti transfer</label><input id="proof" type="file" accept="image/*,.pdf"></div><label>Kode voucher (opsional)</label><input id="voucher" placeholder="Contoh: HEMAT10" autocapitalize="characters"><button id="checkVoucher" class="btn">Gunakan Voucher</button><button id="order" class="btn primary">Buat Pesanan</button><p id="msg" class="msg"></p></div></section></main>`;
wireNav(profile);
const method=document.querySelector("#method"),qrisBox=document.querySelector("#qrisBox"),voucher=document.querySelector("#voucher"),total=document.querySelector("#total"),discountInfo=document.querySelector("#discountInfo"),msg=document.querySelector("#msg"),order=document.querySelector("#order");
let appliedCode="",appliedDiscount=0;
function updateTotal(){const t=Math.max(0,Number(p.price)-appliedDiscount);total.textContent="Rp "+money(t);discountInfo.textContent=appliedDiscount?`Diskon voucher: -Rp ${money(appliedDiscount)}`:"";}
method.onchange=()=>{qrisBox.style.display=method.value==="qris"?"block":"none"};
document.querySelector("#checkVoucher").onclick=async()=>{const code=voucher.value.trim().toUpperCase();if(!code){appliedCode="";appliedDiscount=0;updateTotal();msg.textContent="Kode voucher dikosongkan.";return}msg.textContent="Memeriksa voucher...";const{data:v,error}=await sb.rpc("validate_voucher",{p_code:code,p_price:Number(p.price)});const row=Array.isArray(v)?v[0]:v;if(error||!row){appliedCode="";appliedDiscount=0;updateTotal();msg.textContent=error?.message||"Voucher tidak valid.";return}appliedCode=row.code;appliedDiscount=Number(row.discount||0);updateTotal();msg.textContent=`Voucher ${esc(row.code)} aktif. Hemat Rp ${money(appliedDiscount)}.`};
order.onclick=async()=>{
 order.disabled=true;msg.textContent="Memeriksa...";
 if(normalizeUsername(document.querySelector("#buyer").value)!==profile.username){msg.textContent="Username tidak sesuai dengan akun yang sedang login.";order.disabled=false;return}
 const payMethod=method.value;let proofUrl=null;
 if(payMethod==="qris"){
  const f=document.querySelector("#proof").files[0];if(!f){msg.textContent="Upload bukti pembayaran.";order.disabled=false;return}
  msg.textContent="Mengirim bukti...";const ext=(f.name.split(".").pop()||"bin").toLowerCase();const path=`${u.id}/${crypto.randomUUID()}.${ext}`;const up=await sb.storage.from("payment-proofs").upload(path,f);if(up.error){msg.textContent=up.error.message;order.disabled=false;return}proofUrl=sb.storage.from("payment-proofs").getPublicUrl(path).data.publicUrl;
 } else if(Number(walletBalance)<Math.max(0,Number(p.price)-appliedDiscount)){msg.textContent="Saldo wallet tidak cukup. Silakan isi saldo terlebih dahulu.";order.disabled=false;return}
 msg.textContent="Membuat pesanan...";
 const{error}=await sb.from("orders").insert({user_id:u.id,buyer_name:profile.username,product_id:p.id,product_name:p.name,quantity:1,total:p.price,payment_proof_url:proofUrl,payment_method:payMethod,voucher_code:appliedCode||null});
 if(error){msg.textContent=error.message;order.disabled=false;return}
 msg.textContent=payMethod==="wallet"?"Pesanan dibuat dan saldo ditahan sampai admin memprosesnya.":"Pesanan terkirim. Menunggu persetujuan admin.";setTimeout(()=>location.href="profil.html",900)
};
})();
function money(v){return Number(v||0).toLocaleString("id-ID")}
