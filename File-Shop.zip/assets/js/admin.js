(async()=>{
const a=await requireAdmin();if(!a)return;
const{profile}=a,isOwner=profile.role==="owner";
const $=id=>document.getElementById(id);
const tabs=["overview","orders","products","wallet","vouchers",...(isOwner?["staff"]:[]),"users","notifications","settings"];
adminApp.innerHTML=`<header class="topbar"><a class="brand" href="../dashboard.html">Shopp Digital Admin</a><a class="btn" href="../dashboard.html">Toko</a></header><main class="page"><section class="hero"><span class="eyebrow">${esc(profile.role.toUpperCase())}</span><h1>Admin Panel</h1><p class="muted">Login sebagai ${esc(profile.username)}</p></section><div class="admin-tabs">${tabs.map(x=>`<button data-t="${x}">${x}</button>`).join("")}</div><section id="content"></section></main>`;
document.querySelectorAll("[data-t]").forEach(b=>b.onclick=()=>tab(b.dataset.t));
let orderFilter="pending";
tab("overview");

const loading=()=>{$("content").innerHTML='<div class="center-page"><div class="loader"></div><p>Memuat...</p></div>'};
async function fnError(error){try{const j=await error.context.json();return j.error||error.message}catch(e){return error.message}}
async function staffCall(body){const{data,error}=await sb.functions.invoke("manage-staff",{body});if(error)return{error:await fnError(error)};if(data?.error)return{error:data.error};return{data}}

async function tab(t){
loading();
if(t==="overview"){
 const[{count:p},{count:o},{count:u},{count:pend}]=await Promise.all([
  sb.from("products").select("*",{count:"exact",head:true}),
  sb.from("orders").select("*",{count:"exact",head:true}),
  sb.from("profiles").select("*",{count:"exact",head:true}),
  sb.from("orders").select("*",{count:"exact",head:true}).eq("status","pending")]);
 $("content").innerHTML=`<div class="stats"><div class="card"><b>Produk</b><strong>${p||0}</strong></div><div class="card"><b>Pesanan</b><strong>${o||0}</strong></div><div class="card"><b>Menunggu approval</b><strong>${pend||0}</strong></div><div class="card"><b>User</b><strong>${u||0}</strong></div></div>`;
}

if(t==="products"){
 const [{data:items,error:productError},{data:cats,error:categoryError}]=await Promise.all([sb.from("products").select("*,categories(name)").order("created_at",{ascending:false}),sb.from("categories").select("id,name").order("name")]);
 const options=(cats||[]).map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("");
 $("content").innerHTML=`<div class="card"><h2>Tambah Produk</h2>${categoryError?`<p class="msg">Kategori gagal dimuat: ${esc(categoryError.message)}</p>`:""}${productError?`<p class="msg">Produk gagal dimuat: ${esc(productError.message)}</p>`:""}<form id="add" class="form-grid"><input id="pn" placeholder="Nama" required><input id="price" type="number" min="0" step="1" placeholder="Harga" required><input id="stock" type="number" min="0" value="1" placeholder="Stok"><select id="category"><option value="">Tanpa kategori (Umum)</option>${options}</select><input id="img" placeholder="URL gambar"><input id="download" placeholder="Link download MediaFire/Drive/dll"><textarea id="desc" placeholder="Deskripsi"></textarea><button id="addBtn" class="btn primary">Tambah</button><p id="productMsg" class="msg"></p></form></div><div class="admin-list">${(items||[]).map(p=>`<div class="card row"><div><b>${esc(p.name)}</b><p>Rp ${money(p.price)} · stok ${p.stock} · kategori ${esc(p.categories?.name||"Umum")}</p></div><button class="btn danger del" data-id="${p.id}">Hapus</button></div>`).join("")}</div>`;
 $("add").onsubmit=async e=>{e.preventDefault();const btn=$("addBtn"),msg=$("productMsg");btn.disabled=true;msg.textContent="Menyimpan produk...";const row={name:$("pn").value.trim(),price:Number($("price").value),stock:Number($("stock").value),category_id:$("category").value||null,image_url:$("img").value.trim()||null,download_url:$("download").value.trim()||null,description:$("desc").value.trim()||null};const{error}=await sb.from("products").insert(row);if(error){msg.textContent=`Gagal menyimpan: ${error.message}`;btn.disabled=false}else tab("products")};
 document.querySelectorAll(".del").forEach(b=>b.onclick=async()=>{if(confirm("Hapus?")){b.disabled=true;const{error}=await sb.from("products").delete().eq("id",b.dataset.id);if(error){alert(`Gagal menghapus: ${error.message}`);b.disabled=false}else tab("products")}});
}

if(t==="orders"){
 let q=sb.from("orders").select("*").order("created_at",{ascending:false});
 if(orderFilter!=="all")q=q.eq("status",orderFilter);
 const{data,error}=await q;
 const labels={pending:"Menunggu",approved:"Disetujui",rejected:"Ditolak",all:"Semua"};
 const isImg=u=>/\.(png|jpe?g|gif|webp|bmp)(\?|$)/i.test(u||"");
 const proof=o=>!o.payment_proof_url?"<p class='muted'>Tidak ada bukti pembayaran.</p>":isImg(o.payment_proof_url)?`<a href="${esc(o.payment_proof_url)}" target="_blank" rel="noopener"><img class="proof-thumb" src="${esc(o.payment_proof_url)}" alt="Bukti pembayaran"></a>`:`<a href="${esc(o.payment_proof_url)}" target="_blank" rel="noopener">Buka bukti pembayaran (PDF)</a>`;
 $("content").innerHTML=`<div class="admin-tabs">${Object.keys(labels).map(k=>`<button class="of ${k===orderFilter?"active":""}" data-f="${k}">${labels[k]}</button>`).join("")}</div>${error?`<div class="card">${esc(error.message)}</div>`:`<div class="admin-list">${(data||[]).map(o=>`<div class="card order-admin"><div><b>${esc(o.product_name)}</b><p>Username: <b>${esc(o.buyer_name)}</b></p><p>Rp ${money(o.total)} · ${new Date(o.created_at).toLocaleString("id-ID")}</p><span class="status st-${esc(o.status)}">${esc(o.status)}</span>${o.status==="rejected"&&o.reject_reason?`<p class="muted">Alasan: ${esc(o.reject_reason)}</p>`:""}</div><div>${proof(o)}</div>${o.status==="pending"?`<div class="actions"><button class="btn primary ap" data-id="${o.id}">✓ Approve</button><button class="btn danger rj" data-id="${o.id}">✕ Reject</button></div>`:""}</div>`).join("")||"<div class='card'>Tidak ada pesanan.</div>"}</div>`}`;
 document.querySelectorAll(".of").forEach(b=>b.onclick=()=>{orderFilter=b.dataset.f;tab("orders")});
 document.querySelectorAll(".ap").forEach(b=>b.onclick=async()=>{if(!confirm("Setujui pesanan ini? Bukti pembayaran sudah dicek?"))return;b.disabled=true;const{error}=await sb.rpc("review_order",{p_order:b.dataset.id,p_approve:true});if(error){alert(error.message);b.disabled=false}else tab("orders")});
 document.querySelectorAll(".rj").forEach(b=>b.onclick=async()=>{const r=prompt("Alasan penolakan (akan dilihat pembeli):");if(r===null)return;if(!r.trim()){alert("Alasan wajib diisi.");return}b.disabled=true;const{error}=await sb.rpc("review_order",{p_order:b.dataset.id,p_approve:false,p_reason:r});if(error){alert(error.message);b.disabled=false}else tab("orders")});
}


if(t==="wallet"){
 const{data,error}=await sb.from("wallet_deposits").select("*").order("created_at",{ascending:false}).limit(100);
 const ids=[...new Set((data||[]).map(d=>d.user_id).filter(Boolean))];
 let profileMap={};
 if(ids.length){
  const pr=await sb.from("profiles").select("id,username").in("id",ids);
  (pr.data||[]).forEach(x=>profileMap[x.id]=x.username);
 }
 const isImg=u=>/\.(png|jpe?g|gif|webp|bmp)(\?|$)/i.test(u||"");
 const proof=d=>{
  const u=d.payment_proof_url||d.proof_url;
  if(!u)return `<p class="muted">Tidak ada bukti pembayaran.</p>`;
  return isImg(u)?`<a href="${esc(u)}" target="_blank" rel="noopener"><img class="proof-thumb" src="${esc(u)}" alt="Bukti deposit"></a>`:`<a href="${esc(u)}" target="_blank" rel="noopener">Buka bukti</a>`;
 };
 const normalized=s=>String(s||"").trim().toLowerCase();
 const isProcessed=s=>["approved","rejected"].includes(normalized(s));
 const statusLabel=s=>{const n=normalized(s);return n==="pending"?"PENDING":n==="approved"?"APPROVED":n==="rejected"?"REJECTED":(n||"PENDING").toUpperCase()};
 const renderStatus=d=>statusLabel(d.status);
 $("content").innerHTML=error?`<div class="card">${esc(error.message)}</div>`:`<div class="admin-list">${(data||[]).map(d=>{
  const processed=isProcessed(d.status);
  return `<div class="card order-admin"><div><b>${esc(profileMap[d.user_id]||d.username||"User")}</b><p>Deposit Rp ${money(d.amount)}</p><p>${new Date(d.created_at).toLocaleString("id-ID")}</p><span class="status st-${esc(normalized(d.status)||"pending")}">${esc(renderStatus(d))}</span>${normalized(d.status)==='rejected'&&d.reject_reason?`<p class="muted">Alasan: ${esc(d.reject_reason)}</p>`:""}</div><div>${proof(d)}</div>${!processed?`<div class="actions"><button type="button" class="btn primary da" data-id="${d.id}">✓ Approve</button><button type="button" class="btn danger dr" data-id="${d.id}">✕ Reject</button></div>`:`<div class="muted">Deposit sudah diproses.</div>`}</div>`;
 }).join("")||"<div class='card'>Belum ada deposit.</div>"}</div>`;
 document.querySelectorAll(".da").forEach(b=>b.onclick=async()=>{if(!confirm("Setujui deposit dan tambahkan saldo user?"))return;b.disabled=true;const{error}=await sb.rpc("review_wallet_deposit",{p_deposit:b.dataset.id,p_approve:true});if(error){alert(error.message);b.disabled=false}else tab("wallet")});
 document.querySelectorAll(".dr").forEach(b=>b.onclick=async()=>{const r=prompt("Alasan penolakan:");if(r===null)return;if(!r.trim()){alert("Alasan wajib diisi.");return}b.disabled=true;const{error}=await sb.rpc("review_wallet_deposit",{p_deposit:b.dataset.id,p_approve:false,p_reason:r});if(error){alert(error.message);b.disabled=false}else tab("wallet")});
}

if(t==="vouchers"){
 const{data,error}=await sb.from("vouchers").select("*").order("created_at",{ascending:false});
 const fmt=x=>x.discount_type==='percent'?`${x.discount_value}%`:`Rp ${money(x.discount_value)}`;
 $("content").innerHTML=`<div class="card"><h2>Tambah Voucher</h2><form id="vadd" class="form-grid"><input id="vc" placeholder="Kode, contoh HEMAT10" required><select id="vt"><option value="fixed">Potongan Rupiah</option><option value="percent">Persentase</option></select><input id="vv" type="number" min="1" step="1" placeholder="Nilai diskon" required><input id="vu" type="number" min="0" step="1" value="0" placeholder="Maks penggunaan (0 = unlimited)"><input id="ve" type="datetime-local"><label><input id="va" type="checkbox" checked style="width:auto;margin-right:8px"> Aktif</label><button class="btn primary">Tambah Voucher</button></form><p id="vm" class="msg"></p></div>${error?`<div class="card">${esc(error.message)}</div>`:`<div class="admin-list">${(data||[]).map(v=>`<div class="card row"><div><b>${esc(v.code)}</b><p>${fmt(v)} · ${v.used_count}/${v.max_uses||'∞'} terpakai${v.expires_at?` · exp ${new Date(v.expires_at).toLocaleString("id-ID")}`:""}</p></div><div class="actions"><button class="btn" data-toggle="${v.id}" data-active="${v.is_active}">${v.is_active?'Nonaktifkan':'Aktifkan'}</button><button class="btn danger vd" data-id="${v.id}">Hapus</button></div></div>`).join("")||"<div class='card'>Belum ada voucher.</div>"}</div>`}`;
 $("vadd").onsubmit=async e=>{e.preventDefault();const m=$("vm"),code=$("vc").value.trim().toUpperCase(),value=Number($("vv").value),max=Number($("vu").value||0),raw=$("ve").value;const expires_at=raw?new Date(raw).toISOString():null;const{error}=await sb.from("vouchers").insert({code,discount_type:$("vt").value,discount_value:value,max_uses:max,expires_at,is_active:$("va").checked});m.textContent=error?.message||"Voucher dibuat.";if(!error)setTimeout(()=>tab("vouchers"),500)};
 document.querySelectorAll("[data-toggle]").forEach(b=>b.onclick=async()=>{const{error}=await sb.from("vouchers").update({is_active:b.dataset.active!=="true"}).eq("id",b.dataset.toggle);if(error)alert(error.message);else tab("vouchers")});
 document.querySelectorAll(".vd").forEach(b=>b.onclick=async()=>{if(!confirm("Hapus voucher ini?"))return;const{error}=await sb.from("vouchers").delete().eq("id",b.dataset.id);if(error)alert(error.message);else tab("vouchers")});
}

if(t==="staff"){
 if(!isOwner){$("content").innerHTML='<div class="card">Hanya owner.</div>';return}
 const{data}=await sb.from("profiles").select("id,username,role,created_at").in("role",["admin","owner"]).order("created_at",{ascending:true});
 $("content").innerHTML=`<div class="card"><h2>Tambah Admin / Owner</h2><form id="sadd" class="form-grid"><input id="su" placeholder="Username" autocapitalize="none" required><input id="sp" type="password" placeholder="Password (min 6)" minlength="6" required><select id="sr"><option value="admin">admin</option><option value="owner">owner</option></select><button class="btn primary">Tambah</button></form><p id="smsg" class="msg"></p></div><div class="admin-list">${(data||[]).map(u=>`<details class="card staff-item"><summary><b>${esc(u.username)}</b> <span class="tag">${esc(u.role)}</span>${u.id===profile.id?' <span class="muted">(kamu)</span>':""}</summary><div class="form-grid staff-form"><div><label>Username</label><input class="eu" value="${esc(u.username)}" autocapitalize="none"></div><div><label>Password baru (kosongkan jika tidak diganti)</label><input class="ep" type="password" minlength="6" autocomplete="new-password"></div><div><label>Role</label><select class="er"><option value="user">user (turunkan)</option><option value="admin" ${u.role==="admin"?"selected":""}>admin</option><option value="owner" ${u.role==="owner"?"selected":""}>owner</option></select></div><div class="actions"><button class="btn primary es" data-id="${u.id}">Simpan</button>${u.id!==profile.id?`<button class="btn danger ed" data-id="${u.id}" data-un="${esc(u.username)}">Hapus</button>`:""}</div></div><p class="msg em"></p></details>`).join("")}</div>`;
 $("sadd").onsubmit=async e=>{e.preventDefault();$("smsg").textContent="Menyimpan...";const{error}=await staffCall({action:"create",username:$("su").value,password:$("sp").value,role:$("sr").value});if(error){$("smsg").textContent=error;return}tab("staff")};
 document.querySelectorAll(".es").forEach(b=>b.onclick=async()=>{const box=b.closest("details"),m=box.querySelector(".em"),body={action:"update",id:b.dataset.id,username:box.querySelector(".eu").value,role:box.querySelector(".er").value};const pw=box.querySelector(".ep").value;if(pw)body.password=pw;m.textContent="Menyimpan...";const{error}=await staffCall(body);if(error){m.textContent=error;return}tab("staff")});
 document.querySelectorAll(".ed").forEach(b=>b.onclick=async()=>{if(!confirm(`Hapus akun "${b.dataset.un}" permanen?`))return;const m=b.closest("details").querySelector(".em");m.textContent="Menghapus...";const{error}=await staffCall({action:"delete",id:b.dataset.id});if(error){m.textContent=error;return}tab("staff")});
}

if(t==="users"){
 const{data}=await sb.from("profiles").select("id,username,role").order("created_at",{ascending:false});
 $("content").innerHTML=`<div class="admin-list">${(data||[]).map(u=>`<div class="card row"><div><b>${esc(u.username)}</b></div><span class="tag">${esc(u.role)}</span></div>`).join("")}</div>`;
}

if(t==="notifications"){
 const{data,error}=await sb.from("notifications").select("*").order("created_at",{ascending:false}).limit(100);
 $("content").innerHTML=error?`<div class="card">${esc(error.message)}</div>`:`<div class="admin-list">${(data||[]).map(n=>`<div class="card row"><div><b>${esc(n.title)}</b><p>${esc(n.message)}</p></div><span class="status">${n.is_read?"Dibaca":"Baru"}</span></div>`).join("")||"<div class='card'>Tidak ada notifikasi.</div>"}</div>`;
}

if(t==="settings"){
 const{data:s}=await sb.from("site_settings").select("*").eq("id",1).single();
 $("content").innerHTML=`<div class="card"><label>QRIS URL gambar</label><input id="q" value="${esc(s?.qris_image_url||"")}"><label>Maintenance</label><select id="m"><option value="false" ${!s?.maintenance?"selected":""}>OFF</option><option value="true" ${s?.maintenance?"selected":""}>ON</option></select><label>Pesan maintenance</label><textarea id="mm">${esc(s?.maintenance_message||"")}</textarea><label>CS URL</label><input id="cs" value="${esc(s?.cs_url||"")}"><button id="save" class="btn primary">Simpan</button><p id="sm" class="msg"></p></div>`;
 $("save").onclick=async()=>{const{error}=await sb.from("site_settings").upsert({id:1,qris_image_url:$("q").value||null,maintenance:$("m").value==="true",maintenance_message:$("mm").value,cs_url:$("cs").value||null});$("sm").textContent=error?.message||"Tersimpan."};
}
}
})();
function money(v){return Number(v||0).toLocaleString("id-ID")}
