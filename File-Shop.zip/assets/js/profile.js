(async()=>{
const u=await requireAuth();if(!u)return;
const{profile}=await getUserProfile();
const[{data:o},{data:w}]=await Promise.all([sb.from("orders").select("*,products(download_url)").eq("user_id",u.id).order("created_at",{ascending:false}),sb.from("wallets").select("balance").eq("user_id",u.id).maybeSingle()]);
const label={pending:"Menunggu persetujuan",approved:"Disetujui",rejected:"Ditolak"};
const orderHtml=x=>`<div class="card order"><div><b>${esc(x.product_name)}</b><p class="muted">${new Date(x.created_at).toLocaleString("id-ID")}</p>${x.status==="rejected"&&x.reject_reason?`<p class="muted">Alasan: ${esc(x.reject_reason)}</p>`:""}${x.status==="approved"&&x.products?.download_url?`<a href="${esc(x.products.download_url)}" target="_blank" rel="noopener">Download produk</a>`:""}</div><div><b>Rp ${money(x.total)}</b>${x.discount?`<br><span class="muted">Diskon Rp ${money(x.discount)}</span>`:""}<br><span class="status st-${esc(x.status)}">${esc(label[x.status]||x.status)}</span></div></div>`;
document.querySelector("#app").innerHTML=nav()+`<main class="page"><section class="hero"><h1>Profil</h1><p class="muted">${esc(profile.username)}</p><div class="wallet-mini card">💰 Saldo Wallet: <b>Rp ${money(w?.balance||0)}</b> · <a href="wallet.html">Kelola saldo</a></div></section><section class="card profile-card"><label>Username</label><input value="${esc(profile.username)}" disabled><label>Password baru</label><input id="pw" type="password" minlength="6" autocomplete="new-password"><button id="save" class="btn primary">Ganti Password</button><p id="msg" class="msg"></p></section><h2>Pesanan Saya</h2><section class="order-list">${(o||[]).map(orderHtml).join("")||"<div class='card'>Belum ada pesanan.</div>"}</section></main>`;
wireNav(profile);
save.onclick=async()=>{
 if(pw.value.length<6){msg.textContent="Password minimal 6 karakter.";return}
 const{error}=await sb.auth.updateUser({password:pw.value});
 msg.textContent=error?error.message:"Password diganti.";if(!error)pw.value=""
}
})();
function money(v){return Number(v||0).toLocaleString("id-ID")}
