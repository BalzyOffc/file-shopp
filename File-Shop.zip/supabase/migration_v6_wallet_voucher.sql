-- Shopp Digital V6: Wallet/Saldo + Voucher
-- Jalankan SETELAH migration_v5.sql pada database yang sudah berjalan.

create extension if not exists pgcrypto;

-- ===== WALLET =====
create table if not exists public.wallets(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null unique references public.profiles(id) on delete cascade,
 balance numeric(14,2) not null default 0 check(balance >= 0),
 created_at timestamptz not null default now(),
 updated_at timestamptz not null default now()
);

create table if not exists public.wallet_deposits(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 amount numeric(14,2) not null check(amount > 0),
 payment_proof_url text not null,
 status text not null default 'pending' check(status in('pending','approved','rejected')),
 reject_reason text,
 reviewed_by uuid references public.profiles(id) on delete set null,
 reviewed_at timestamptz,
 created_at timestamptz not null default now()
);

create table if not exists public.wallet_transactions(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references public.profiles(id) on delete cascade,
 type text not null check(type in('deposit','purchase','refund','adjustment')),
 amount numeric(14,2) not null,
 balance_after numeric(14,2) not null,
 reference_type text,
 reference_id uuid,
 note text,
 created_at timestamptz not null default now()
);

insert into public.wallets(user_id)
select id from public.profiles
on conflict(user_id) do nothing;

-- ===== VOUCHERS =====
create table if not exists public.vouchers(
 id uuid primary key default gen_random_uuid(),
 code text not null unique,
 discount_type text not null default 'fixed' check(discount_type in('fixed','percent')),
 discount_value numeric(14,2) not null check(discount_value > 0),
 max_uses integer not null default 0 check(max_uses >= 0),
 used_count integer not null default 0 check(used_count >= 0),
 expires_at timestamptz,
 is_active boolean not null default true,
 created_at timestamptz not null default now()
);

create table if not exists public.voucher_redemptions(
 id uuid primary key default gen_random_uuid(),
 voucher_id uuid not null references public.vouchers(id) on delete cascade,
 user_id uuid not null references public.profiles(id) on delete cascade,
 order_id uuid not null unique references public.orders(id) on delete cascade,
 created_at timestamptz not null default now()
);

-- ===== TAMBAHAN ORDERS =====
alter table public.orders add column if not exists payment_method text not null default 'qris';
alter table public.orders add column if not exists voucher_code text;
alter table public.orders add column if not exists discount numeric(14,2) not null default 0;
alter table public.orders add column if not exists subtotal numeric(14,2) not null default 0;
alter table public.orders add column if not exists wallet_charged numeric(14,2) not null default 0;

-- Constraint aman untuk database lama.
alter table public.orders drop constraint if exists orders_payment_method_check;
alter table public.orders add constraint orders_payment_method_check check(payment_method in('qris','wallet'));

-- ===== ORDER TRIGGER =====
create or replace function public.orders_before_insert() returns trigger
language plpgsql security definer set search_path=public as $$
declare
 v_user text;
 v_prod record;
 v_wallet numeric(14,2);
 v_discount numeric(14,2):=0;
 v_code text;
begin
 select username into v_user from public.profiles where id=new.user_id;
 if v_user is null or lower(trim(coalesce(new.buyer_name,'')))<>v_user then
  raise exception 'Username tidak sesuai dengan akun.';
 end if;

 select name,price,stock,is_active into v_prod
 from public.products where id=new.product_id;
 if not found or not v_prod.is_active then raise exception 'Produk tidak tersedia.'; end if;
 if v_prod.stock<=0 then raise exception 'Stok produk habis.'; end if;

 new.buyer_name:=v_user;
 new.product_name:=v_prod.name;
 new.quantity:=1;
 new.subtotal:=v_prod.price;
 new.discount:=0;
 new.wallet_charged:=0;
 new.status:='pending';
 new.reject_reason:=null;
 new.reviewed_by:=null;
 new.reviewed_at:=null;
 new.payment_method:=coalesce(nullif(new.payment_method,''),'qris');

 if new.payment_method='qris' then
  if coalesce(new.payment_proof_url,'')='' then raise exception 'Bukti pembayaran wajib diunggah.'; end if;
 elsif new.payment_method='wallet' then
  new.payment_proof_url:=null;
 else
  raise exception 'Metode pembayaran tidak valid.';
 end if;

 v_code:=upper(trim(coalesce(new.voucher_code,'')));
 if v_code<>'' then
  select case
    when discount_type='percent' then least(v_prod.price,(v_prod.price*discount_value/100))
    else least(v_prod.price,discount_value)
  end
  into v_discount
  from public.vouchers
  where code=v_code and is_active=true
    and (expires_at is null or expires_at>now())
    and (max_uses=0 or used_count<max_uses);
  if not found then raise exception 'Voucher tidak valid, sudah habis, atau sudah expired.'; end if;
  new.voucher_code:=v_code;
 else
  new.voucher_code:=null;
 end if;

 new.discount:=coalesce(v_discount,0);
 new.total:=greatest(0,v_prod.price-new.discount);

 if new.payment_method='wallet' then
  select balance into v_wallet from public.wallets where user_id=new.user_id for update;
  if v_wallet is null then
   insert into public.wallets(user_id,balance) values(new.user_id,0)
   on conflict(user_id) do nothing;
   select balance into v_wallet from public.wallets where user_id=new.user_id for update;
  end if;
  if v_wallet < new.total then raise exception 'Saldo wallet tidak cukup.'; end if;
  update public.wallets set balance=balance-new.total,updated_at=now() where user_id=new.user_id;
  new.wallet_charged:=new.total;
 end if;
 return new;
end $$;

drop trigger if exists trg_orders_before_insert on public.orders;
create trigger trg_orders_before_insert before insert on public.orders for each row execute procedure public.orders_before_insert();

-- Reservasi voucher dilakukan setelah order punya ID. Jika gagal, seluruh insert dibatalkan.
create or replace function public.reserve_voucher_after_order() returns trigger
language plpgsql security definer set search_path=public as $$
declare v_id uuid; v_ok integer;
begin
 if nullif(trim(coalesce(new.voucher_code,'')),'') is null then return new; end if;
 select id into v_id from public.vouchers where code=upper(trim(new.voucher_code)) for update;
 if v_id is null then raise exception 'Voucher tidak ditemukan.'; end if;
 update public.vouchers
 set used_count=used_count+1
 where id=v_id and (max_uses=0 or used_count<max_uses) and is_active=true
   and (expires_at is null or expires_at>now());
 get diagnostics v_ok = row_count;
 if v_ok<>1 then raise exception 'Voucher sudah habis atau tidak aktif.'; end if;
 insert into public.voucher_redemptions(voucher_id,user_id,order_id)
 values(v_id,new.user_id,new.id);
 return new;
end $$;

drop trigger if exists trg_reserve_voucher on public.orders;
create trigger trg_reserve_voucher after insert on public.orders for each row execute procedure public.reserve_voucher_after_order();

-- ===== REVIEW ORDER: refund wallet jika ditolak + notifikasi buyer =====
create or replace function public.review_order(p_order uuid,p_approve boolean,p_reason text default null)
returns void language plpgsql security definer set search_path=public as $$
declare v_order public.orders%rowtype; v_balance numeric(14,2);
begin
 if not public.is_staff() then raise exception 'Hanya admin/owner yang boleh memproses pesanan.'; end if;
 if not p_approve and nullif(trim(coalesce(p_reason,'')),'') is null then raise exception 'Alasan penolakan wajib diisi.'; end if;
 select * into v_order from public.orders where id=p_order and status='pending' for update;
 if not found then raise exception 'Pesanan tidak ditemukan atau sudah diproses.'; end if;

 update public.orders set
  status=case when p_approve then 'approved' else 'rejected' end,
  reject_reason=case when p_approve then null else trim(p_reason) end,
  reviewed_by=auth.uid(),reviewed_at=now()
 where id=p_order;

 if not p_approve then
  if coalesce(v_order.wallet_charged,0)>0 then
   select balance into v_balance from public.wallets where user_id=v_order.user_id for update;
   update public.wallets set balance=balance+v_order.wallet_charged,updated_at=now() where user_id=v_order.user_id;
   insert into public.wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,note)
   select v_order.user_id,'refund',v_order.wallet_charged,balance,'order',v_order.id,'Refund saldo karena pesanan ditolak'
   from public.wallets where user_id=v_order.user_id;
  end if;
  if nullif(trim(coalesce(v_order.voucher_code,'')),'') is not null then
   update public.vouchers set used_count=greatest(0,used_count-1) where code=v_order.voucher_code;
   delete from public.voucher_redemptions where order_id=v_order.id;
  end if;
 end if;

 insert into public.notifications(user_id,title,message,type)
 values(v_order.user_id,
  case when p_approve then 'Pesanan disetujui' else 'Pesanan ditolak' end,
  case when p_approve then 'Pesanan '||v_order.product_name||' telah disetujui.' else 'Pesanan '||v_order.product_name||' ditolak: '||trim(p_reason) end,
  'order');
end $$;
revoke all on function public.review_order(uuid,boolean,text) from public,anon;
grant execute on function public.review_order(uuid,boolean,text) to authenticated;

-- ===== DEPOSIT WALLET =====
create or replace function public.review_wallet_deposit(p_deposit uuid,p_approve boolean,p_reason text default null)
returns void language plpgsql security definer set search_path=public as $$
declare v public.wallet_deposits%rowtype; v_balance numeric(14,2);
begin
 if not public.is_staff() then raise exception 'Hanya admin/owner yang boleh memproses deposit.'; end if;
 if not p_approve and nullif(trim(coalesce(p_reason,'')),'') is null then raise exception 'Alasan penolakan wajib diisi.'; end if;
 select * into v from public.wallet_deposits where id=p_deposit and status='pending' for update;
 if not found then raise exception 'Deposit tidak ditemukan atau sudah diproses.'; end if;
 update public.wallet_deposits set status=case when p_approve then 'approved' else 'rejected' end,
  reject_reason=case when p_approve then null else trim(p_reason) end,reviewed_by=auth.uid(),reviewed_at=now() where id=p_deposit;
 if p_approve then
  insert into public.wallets(user_id,balance) values(v.user_id,0) on conflict(user_id) do nothing;
  select balance into v_balance from public.wallets where user_id=v.user_id for update;
  update public.wallets set balance=balance+v.amount,updated_at=now() where user_id=v.user_id returning balance into v_balance;
  insert into public.wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,note)
  values(v.user_id,'deposit',v.amount,v_balance,'wallet_deposit',v.id,'Deposit QRIS disetujui admin');
  insert into public.notifications(user_id,title,message,type)
  values(v.user_id,'Saldo bertambah','Deposit Rp '||to_char(v.amount,'FM999G999G999G990')||' disetujui.','wallet');
 else
  insert into public.notifications(user_id,title,message,type)
  values(v.user_id,'Deposit ditolak','Deposit Rp '||to_char(v.amount,'FM999G999G999G990')||' ditolak: '||trim(p_reason),'wallet');
 end if;
end $$;
revoke all on function public.review_wallet_deposit(uuid,boolean,text) from public,anon;
grant execute on function public.review_wallet_deposit(uuid,boolean,text) to authenticated;


-- User hanya perlu memeriksa voucher lewat RPC, bukan membaca tabel voucher langsung.
create or replace function public.validate_voucher(p_code text,p_price numeric)
returns table(code text,discount_type text,discount_value numeric,discount numeric,total numeric)
language plpgsql security definer set search_path=public as $$
declare v public.vouchers%rowtype; d numeric(14,2);
begin
 select * into v from public.vouchers where code=upper(trim(coalesce(p_code,''))) and is_active=true
   and (expires_at is null or expires_at>now()) and (max_uses=0 or used_count<max_uses);
 if not found then raise exception 'Voucher tidak valid, sudah habis, atau sudah expired.'; end if;
 if p_price is null or p_price<0 then raise exception 'Harga tidak valid.'; end if;
 d:=case when v.discount_type='percent' then least(p_price,p_price*v.discount_value/100) else least(p_price,v.discount_value) end;
 return query select v.code,v.discount_type,v.discount_value,d,greatest(0,p_price-d);
end $$;
revoke all on function public.validate_voucher(text,numeric) from public,anon;
grant execute on function public.validate_voucher(text,numeric) to authenticated;

-- ===== RLS WALLET =====
alter table public.wallets enable row level security;
alter table public.wallet_deposits enable row level security;
alter table public.wallet_transactions enable row level security;
alter table public.vouchers enable row level security;
alter table public.voucher_redemptions enable row level security;

drop policy if exists wallets_select on public.wallets;
create policy wallets_select on public.wallets for select using(user_id=auth.uid() or public.is_staff());
drop policy if exists deposits_select on public.wallet_deposits;
create policy deposits_select on public.wallet_deposits for select using(user_id=auth.uid() or public.is_staff());
drop policy if exists deposits_insert on public.wallet_deposits;
create policy deposits_insert on public.wallet_deposits for insert to authenticated with check(user_id=auth.uid() and status='pending');
drop policy if exists wallet_tx_select on public.wallet_transactions;
create policy wallet_tx_select on public.wallet_transactions for select using(user_id=auth.uid() or public.is_staff());
drop policy if exists vouchers_staff on public.vouchers;
create policy vouchers_staff on public.vouchers for all using(public.is_staff()) with check(public.is_staff());
drop policy if exists voucher_redemptions_select on public.voucher_redemptions;
create policy voucher_redemptions_select on public.voucher_redemptions for select using(user_id=auth.uid() or public.is_staff());

-- User tidak dapat mengubah saldo/status deposit/transaksi secara langsung.
drop policy if exists wallets_write on public.wallets;
drop policy if exists deposits_update on public.wallet_deposits;
drop policy if exists deposits_delete on public.wallet_deposits;
drop policy if exists wallet_tx_insert on public.wallet_transactions;
drop policy if exists voucher_redemptions_insert on public.voucher_redemptions;

-- Storage bucket yang sama dipakai untuk bukti transfer wallet.
insert into storage.buckets(id,name,public) values('payment-proofs','payment-proofs',true)
on conflict(id) do update set public=true;

-- Pastikan setiap akun baru otomatis memiliki wallet kosong.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
 insert into public.profiles(id,username)
 values(new.id,lower(coalesce(nullif(new.raw_user_meta_data->>'username',''),split_part(new.email,'@',1))))
 on conflict(id) do update set username=excluded.username;
 insert into public.wallets(user_id,balance) values(new.id,0) on conflict(user_id) do nothing;
 return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();

-- Catat transaksi pembelian wallet setelah order berhasil dibuat.
create or replace function public.record_wallet_purchase_after_order() returns trigger
language plpgsql security definer set search_path=public as $$
declare v_balance numeric(14,2);
begin
 if coalesce(new.wallet_charged,0)>0 then
  select balance into v_balance from public.wallets where user_id=new.user_id;
  insert into public.wallet_transactions(user_id,type,amount,balance_after,reference_type,reference_id,note)
  values(new.user_id,'purchase',-new.wallet_charged,v_balance,'order',new.id,'Pembayaran order menggunakan wallet');
 end if;
 return new;
end $$;
drop trigger if exists trg_record_wallet_purchase on public.orders;
create trigger trg_record_wallet_purchase after insert on public.orders for each row execute procedure public.record_wallet_purchase_after_order();

-- User dapat melihat notifikasi miliknya; staff tetap dapat melihat semua notifikasi.
drop policy if exists notif_user_read on public.notifications;
create policy notif_user_read on public.notifications for select using(user_id=auth.uid() or public.is_staff());
