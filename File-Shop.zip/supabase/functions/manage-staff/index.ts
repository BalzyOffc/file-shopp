import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
const ROLES = ["user", "admin", "owner"];
const DOMAIN = Deno.env.get("AUTH_EMAIL_DOMAIN") || "shopp-digital-freefire.netlify.app"; // harus sama dengan AUTH_EMAIL_DOMAIN di config.js
const norm = (v: unknown) => String(v ?? "").trim().toLowerCase();
const okUsername = (v: string) => /^[a-z0-9_.]{3,20}$/.test(v);

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // 1. Pastikan pemanggil adalah OWNER (dicek dari JWT + tabel profiles)
    const token = (req.headers.get("Authorization") || "").replace("Bearer ", "");
    const { data: { user }, error: uErr } = await admin.auth.getUser(token);
    if (uErr || !user) return json({ error: "Sesi tidak valid." }, 401);
    const { data: me } = await admin.from("profiles").select("role").eq("id", user.id).maybeSingle();
    if (me?.role !== "owner") return json({ error: "Hanya owner yang boleh mengelola admin/owner." }, 403);

    const b = await req.json();
    const action = b.action;

    const ownerCount = async () => (await admin.from("profiles").select("id", { count: "exact", head: true }).eq("role", "owner")).count || 0;
    const usernameTaken = async (u: string, exceptId?: string) => {
      const { data } = await admin.from("profiles").select("id").eq("username", u).maybeSingle();
      return !!data && data.id !== exceptId;
    };

    if (action === "create") {
      const username = norm(b.username), password = String(b.password || ""), role = b.role;
      if (!okUsername(username)) return json({ error: "Username 3-20 karakter: huruf kecil, angka, _ atau ." }, 400);
      if (password.length < 6) return json({ error: "Password minimal 6 karakter." }, 400);
      if (!["admin", "owner"].includes(role)) return json({ error: "Role harus admin atau owner." }, 400);
      if (await usernameTaken(username)) return json({ error: "Username sudah dipakai." }, 400);
      const { data, error } = await admin.auth.admin.createUser({ email: `${username}@${DOMAIN}`, password, email_confirm: true, user_metadata: { username } });
      if (error) return json({ error: error.message }, 400);
      const { error: pErr } = await admin.from("profiles").update({ role }).eq("id", data.user.id);
      if (pErr) return json({ error: pErr.message }, 400);
      return json({ ok: true, id: data.user.id });
    }

    if (action === "update") {
      const id = String(b.id || "");
      const { data: target } = await admin.from("profiles").select("id,username,role").eq("id", id).maybeSingle();
      if (!target) return json({ error: "User tidak ditemukan." }, 404);
      const authPatch: Record<string, unknown> = {};
      const profPatch: Record<string, unknown> = {};

      if (b.username !== undefined && norm(b.username) !== target.username) {
        const username = norm(b.username);
        if (!okUsername(username)) return json({ error: "Username 3-20 karakter: huruf kecil, angka, _ atau ." }, 400);
        if (await usernameTaken(username, id)) return json({ error: "Username sudah dipakai." }, 400);
        authPatch.email = `${username}@${DOMAIN}`; authPatch.email_confirm = true; authPatch.user_metadata = { username };
        profPatch.username = username;
      }
      if (b.password) {
        if (String(b.password).length < 6) return json({ error: "Password minimal 6 karakter." }, 400);
        authPatch.password = String(b.password);
      }
      if (b.role !== undefined && b.role !== target.role) {
        if (!ROLES.includes(b.role)) return json({ error: "Role tidak valid." }, 400);
        if (target.role === "owner" && (await ownerCount()) <= 1) return json({ error: "Tidak boleh menurunkan owner terakhir." }, 400);
        profPatch.role = b.role;
      }
      if (Object.keys(authPatch).length) {
        const { error } = await admin.auth.admin.updateUserById(id, authPatch);
        if (error) return json({ error: error.message }, 400);
      }
      if (Object.keys(profPatch).length) {
        const { error } = await admin.from("profiles").update(profPatch).eq("id", id);
        if (error) return json({ error: error.message }, 400);
      }
      return json({ ok: true });
    }

    if (action === "delete") {
      const id = String(b.id || "");
      if (id === user.id) return json({ error: "Tidak bisa menghapus akun sendiri." }, 400);
      const { data: target } = await admin.from("profiles").select("role").eq("id", id).maybeSingle();
      if (!target) return json({ error: "User tidak ditemukan." }, 404);
      if (target.role === "owner" && (await ownerCount()) <= 1) return json({ error: "Tidak boleh menghapus owner terakhir." }, 400);
      const { error } = await admin.auth.admin.deleteUser(id); // profiles ikut terhapus (on delete cascade)
      if (error) return json({ error: error.message }, 400);
      return json({ ok: true });
    }

    return json({ error: "Action tidak dikenal." }, 400);
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : String(e) }, 400);
  }
});
